/* must include
	-create array of pointers, classRosterArray to hold the data provided in the studentDataTable
	2.  Create a student object for each student in the data table and populate classRosterArray.

a.  Parse each set of data identified in the “studentData Table.”

b.  Add each student object to classRosterArray.

3.  Define the following functions:

a.  public void add(string studentID, string firstName, string lastName, string emailAddress, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram degreeprogram)  that sets the instance variables from part D1 and updates the roster.

b.  public void remove(string studentID)  that removes students from the roster by student ID. If the student ID does not exist, the function prints an error message indicating that the student was not found.

c. public void printAll() that prints a complete tab-separated list of student data in the provided format: A1 [tab] First Name: John [tab] Last Name: Smith [tab] Age: 20 [tab]daysInCourse: {35, 40, 55} Degree Program: Security. The printAll() function should loop through all the students in classRosterArray and call the print() function for each student.

d.  public void printAverageDaysInCourse(string studentID)  that correctly prints a student’s average number of days in the three courses. The student is identified by the studentID parameter.

e.  public void printInvalidEmails() that verifies student email addresses and displays all invalid email addresses to the user.


Note: A valid email should include an at sign ('@') and period ('.') and should not include a space (' ').


f.  public void printByDegreeProgram(DegreeProgram degreeProgram) that prints out student information for a degree program specified by an enumerated type.


*/

#include <string>
#include "roster.h"
#include "degree.h"

using namespace std;


// default constructor
Roster::Roster() {
	numberOfStudents = 0;
	lastValue = -1;
	classRosterArray = nullptr;
}
// main constructor
Roster::Roster(int capacity) {
	numberOfStudents = capacity;
	lastValue = -1;
	classRosterArray = new Student * [numberOfStudents];
}

// destructor
Roster::~Roster() {

	for (int i = 0; i < numberOfStudents; i++) {
		cout << "Deleting student " << classRosterArray[i]->getStudentID() << endl;
		if (classRosterArray[i] != NULL) {
			delete this->classRosterArray[i];
		}
	}
	delete classRosterArray;
}

// adds each student to the roster
void Roster::add(string studentID, string firstName, string lastName, string emailAddress, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram degreeProgram) {


	if (lastValue < numberOfStudents) lastValue++;

	classRosterArray[lastValue] = new Student();

	int days[] = { daysInCourse1, daysInCourse2, daysInCourse3 };

	classRosterArray[lastValue]->setStudentID(studentID);

	classRosterArray[lastValue]->setFirstName(firstName);

	classRosterArray[lastValue]->setLastName(lastName);

	classRosterArray[lastValue]->setEmailAddress(emailAddress);

	classRosterArray[lastValue]->setAge(age);

	classRosterArray[lastValue]->setCourseTime(days);

	classRosterArray[lastValue]->setDegreeProgram(degreeProgram);
}

// prints all students out
void Roster::printAll() {

	cout << "Displaying all students..." << endl << endl;

	for (int i = 0; i <= lastValue; i++) {
		(this->classRosterArray)[i]->print();
	}

	cout << endl << "All students displayed." << endl << endl << endl;
}

// removes students from the roster
void Roster::remove(string studentID) {
	bool found = false;
	cout << "Removing student with ID " << studentID << "..." << endl;
	for (int i = 0; i <= lastValue; i++) {
		if (this->classRosterArray[i]->getStudentID() == studentID) {
			// to avoid having a gap in the array, I put the last index into the deleted index. I could just shift everything up an index, but that would take some time
			found = true;
			delete this->classRosterArray[i];
			this->classRosterArray[i] = this->classRosterArray[lastValue];
			lastValue--;
			numberOfStudents--;
			cout << studentID << " successfully removed" << endl << endl << endl;
		}
	}
	if (!found) {
		cout << "Student with ID " << studentID << " could not be found!" << endl << endl << endl;
	}
}

// prints average number of days to complete each course
void Roster::printAverageDaysInCourse(string studentID) {

	bool found = false;

	for (int i = 0; i <= lastValue; i++) {
		if (this->classRosterArray[i]->getStudentID() == studentID) {
			found = true;
			int* c = classRosterArray[i]->getCourseTime();
			cout << "Average course time of " << studentID << " is " << ((c[0] + c[1] + c[2]) / 3) << endl;
		}
	}
	if (!found) {
		cout << studentID << " could not be found!" << endl << endl << endl;
	}
}

// prints invalid emails
void Roster::printInvalidEmails() {

	cout << "Checking entries for invalid email addresses..." << endl << endl;
	bool invalidEmail = false;
	string email;


	for (int i = 0; i < lastValue; i++) {

		email = this->classRosterArray[i]->getEmailAddress();

		// this part was a little tricky. the find function doesn't return a true or false, just the position of the parameter.
		// if the character isn't found, it returns a huge number, so a regular if statement would always say true. 
		//By comparing the position to the size of the string, I can figure out if it is too large
		if (email.find('@') > email.size() || email.find('.') > email.size() || email.find(' ') < email.size()) {
			invalidEmail = true;
			cout << email << " is not a valid email address!" << endl;
		}
	}

	if (!invalidEmail) {
		cout << "No invalid emails found" << endl;
	}

	cout << endl << "All students with invalid email addresses displayed." << endl << endl << endl;

}

//prints by degree program
void Roster::printByDegree(DegreeProgram dgree) {

	cout << "Printing all students studying " << degreeTypeStrings[dgree] << "..." << endl << endl;
	for (int i = 0; i <= lastValue; i++) {
		if (this->classRosterArray[i]->getDegreeProgram() == dgree) {
			this->classRosterArray[i]->print();
		}
	}
	cout << endl << "All students printed" << endl << endl << endl;
}




