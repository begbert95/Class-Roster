//Class roster by Brandon Egbert in C++
//Note that the assignment doesn't call for a lot of error checking or varying data, so it isn't very robust
//Requirements for the main program are below

/*
F.  Demonstrate the program’s required functionality by adding a main() function in main.cpp, which will contain the required function calls to achieve the following results:

1.  Print out to the screen, via your application, the course title, the programming language used, your WGU student ID, and your name.

2.  Create an instance of the Roster class called classRoster.

3.  Add each student to classRoster.

4.  Convert the following pseudo code to complete the rest of the  main() function:

classRoster.printAll();

classRoster.printInvalidEmails();



//loop through classRosterArray and for each element:

classRoster.printAverageDaysInCourse(*current_object's student id*);



classRoster.printByDegreeProgram(SOFTWARE);

classRoster.remove("A3");

classRoster.printAll();

classRoster.remove("A3");

//expected: the above line should print a message saying such a student with this ID was not found.

5.  Implement the destructor to release the memory that was allocated dynamically in Roster.


G.  Demonstrate professional communication in the content and presentation of your submission.
*/


#include <iostream>
#include <string>
#include <iomanip>
#include "roster.h"
using namespace std;

// the data is hard coded in here. Not feasible outside this project, but it does make things easy
const string studentData[] = {
		"A1,John,Smith,John1989@gm ail.com,20,30,35,40,SECURITY",
		"A2,Suzan,Erickson,Erickson_1990@gmailcom,19,50,30,40,NETWORK",
		"A3,Jack,Napoli,The_lawyer99yahoo.com,19,20,40,33,SOFTWARE",
		"A4,Erin,Black,Erin.black@comcast.net,22,50,58,40,SECURITY",
		"A5,Brandon,Egbert,begber3@wgu.edu,25,15,42,13,SOFTWARE"
};


int main() {


	cout << "Scripting and Programming - Applications – C867" << endl;
	cout << "Written by Brandon Egbert (begber3) in C++" << endl << endl;

	// dynamically finds the size of the data. While the requirements were only for 5 students, I opted to make this capable of handling more
	int totalCount = sizeof(studentData) / sizeof(studentData[0]);

	// initializing variables
	int age, days1, days2, days3;
	string id, first, last, email, degParse;
	DegreeProgram deg;
	Roster* classRoster = new Roster(totalCount);


	// this states how much data it is processing, so you have an idea of how long it will take
	cout << "Processing " << totalCount << " entries..." << endl;

	// for loop to search through the studentData array above, delimiting by commas
	// x is the location of the next comma, and y is the location of the previous one
	for (int i = 0; i < totalCount; i++) {

		int x = studentData[i].find(",");
		id = studentData[i].substr(0, x);

		int y = x + 1;
		x = studentData[i].find(",", y);
		first = studentData[i].substr(y, x - y);

		y = x + 1;
		x = studentData[i].find(",", y);
		last = studentData[i].substr(y, x - y);

		y = x + 1;
		x = studentData[i].find(",", y);
		email = studentData[i].substr(y, x - y);

		y = x + 1;
		x = studentData[i].find(",", y);
		age = stoi(studentData[i].substr(y, x - y));

		y = x + 1;
		x = studentData[i].find(",", y);
		days1 = stoi(studentData[i].substr(y, x - y));

		y = x + 1;
		x = studentData[i].find(",", y);
		days2 = stoi(studentData[i].substr(y, x - y));

		y = x + 1;
		x = studentData[i].find(",", y);
		days3 = stoi(studentData[i].substr(y, x - y));

		y = x + 1;
		x = studentData[i].find(",", y);
		degParse = studentData[i].substr(y, x - y);

		// conditionals based on the last part of the data. A switch statement would work here, but it would be more difficult to read
		// it would be better to pass degParse directly, but you would need to convert the data
		if (degParse == "NETWORK") {
			classRoster->add(id, first, last, email, age, days1, days2, days3, NETWORK);
		}
		else if (degParse == "SECURITY") {
			classRoster->add(id, first, last, email, age, days1, days2, days3, SECURITY);
		}
		else if (degParse == "SOFTWARE") {
			classRoster->add(id, first, last, email, age, days1, days2, days3, SOFTWARE);
		}
	}


	// checkpoint to help distinguish what is happening
	cout << "Done processing data." << endl << endl << endl;

	classRoster->printAll();

	classRoster->printInvalidEmails();

	// checkpoint to help distinguish what is happening
	cout << "Printing the average days per course for each student..." << endl << endl;

	//since the printAverageDaysInCourse function requires a student ID, this loops through each student. I think having the function do it would be better, but that's just me
	for (int i = 0; i < totalCount; i++) {
		classRoster->printAverageDaysInCourse(classRoster->classRosterArray[i]->getStudentID());
	}

	// checkpoint to help distinguish what is happening
	cout << endl << "All average course times displayed." << endl << endl << endl;

	classRoster->printByDegree(SOFTWARE);

	classRoster->remove("A3");

	classRoster->printAll();


	// the assignment requires removing the same entry, hence why this is listed a second time
	classRoster->remove("A3");

	// checkpoint to help distinguish what is happening
	cout << "Releasing memory..." << endl << endl;

	// calling the destructor to release memory
	classRoster->~Roster();

	// checkpoint to help distinguish what is happening
	cout << endl << "Memory released. Thank you!" << endl << endl;

	//leaves the cmd window up to view the data
	system("pause");
	return 0;

};