#include <string>

// include guard to make sure this is only included once. On such a small program, it isn't really useful, but it's best practice to always include it
#ifndef DEGREE_H
#define DEGREE_H

// I didn't use the enum class here because it doesn't interact with degreeTypeStrings. It could be done, but I wanted to play around with it like this
enum DegreeProgram { SECURITY, NETWORK, SOFTWARE };
static const std::string degreeTypeStrings[] = { "SECURITY", "NETWORK", "SOFTWARE" };

#endif