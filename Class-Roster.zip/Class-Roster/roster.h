// header file
#include <iostream>
#include <string>
#include "student.h"

// include guard to make sure this is only included once. On such a small program, it isn't really useful, but it's best practice to always include it
#ifndef ROSTER_H
#define ROSTER_H

class Roster {
public:
	int lastValue;
	int numberOfStudents;
	Student** classRosterArray;

	Roster();
	Roster(int numberOfStudents);
	void add(string studentID, string firstName, string lastName, string emailAddress, int age, int daysInCourse1, int daysInCourse2, int daysInCourse3, DegreeProgram degreeprogram);
	void printAll();
	void remove(string studentID);
	void printAverageDaysInCourse(string studentID);
	void printInvalidEmails();
	void printByDegree(DegreeProgram dgree);
	~Roster();

};
#endif

