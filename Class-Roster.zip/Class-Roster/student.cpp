/*
D.  For the Student class, do the following:

1.  Create the class Student  in the files student.h and student.cpp, which includes each of the following variables:

•  student ID
•  first name
•   last name
•  email address
•  age
•  array of number of days to complete each course
•  degree program

2.  Create each of the following functions in the Student class:
a.  an accessor (i.e., getter) for each instance variable from part D1
b.  a mutator (i.e., setter) for each instance variable from part D1
c.  All external access and changes to any instance variables of the Student class must be done using accessor and mutator functions.
d.  constructor using all of the input parameters provided in the table
e.  print() to print specific student data
*/
/* must contain these variables:
	- student ID
	- first name
	- last name
	- email address
	- age
	- array of number of days to complete each course
	- degree program
*/

/* needed functions
	- accessor/getter for each variable
	- mutator/setter for each variable
		-all access and changes must be made using the above
	- constructor using all of the input parameters provided in the table
	- print() to print specific data
*/

#include <iostream>
#include <string>
#include <iomanip>
#include "student.h"
using namespace std;

//default constructor. Since all of the data is hard-coded in, there isn't really a need to have this, but it's nice to have
Student::Student() {
	studentID = "EMPTY";
	firstName = "EMPTY";
	lastName = "EMPTY";
	emailAddress = "EMPTY";
	age = -1;
	courseTime = new int[courseArraySize];
	for (int i = 0; i <= 2; i++) {
		courseTime[i] = 0;
	}

	degree = NETWORK;

}
// the main constructor
Student::Student(string studentIDParam, string firstNameParam, string lastNameParam, string emailAddressParam, int ageParam, int* courseTimeParam, DegreeProgram degreeProgramParam) {
	studentID = studentIDParam;
	firstName = firstNameParam;
	lastName = lastNameParam;
	emailAddress = emailAddressParam;
	age = ageParam;
	courseTime = courseTimeParam;
	degree = degreeProgramParam;

}
//destructor
Student::~Student() {
	if (courseTime != nullptr) {
		delete[] courseTime;
		courseTime = nullptr;
	}
}


void Student::print() {

	cout << studentID << "\t";
	cout << firstName << "\t";

	// because the assignment asked for the data to be separated by tabs, two entries didn't line up correctly
	// the next two conditionals use the last name to change the formatting. Setting the width would fix the issue

	if (lastName == "Erickson") cout << lastName << "\t";
	else cout << lastName << "\t\t";

	if (lastName == "Egbert") cout << emailAddress << "\t\t";
	else cout << emailAddress << "\t";

	cout << age << "\t";
	cout << courseTime[0] << ", " << courseTime[1] << ", " << courseTime[2] << "\t";
	cout << degreeTypeStrings[degree] << endl;
}



//setters

void Student::setStudentID(string pram) {
	studentID = pram;
}

void Student::setFirstName(string pram) {
	firstName = pram;
}

void Student::setLastName(string pram) {
	lastName = pram;
}

void Student::setEmailAddress(string pram) {
	emailAddress = pram;
}

void Student::setAge(int pram) {
	age = pram;
}

void Student::setCourseTime(int pram[]) {
	courseTime = new int[courseArraySize];
	for (int i = 0; i < 3; i++) {
		courseTime[i] = pram[i];
	}
}

void Student::setDegreeProgram(DegreeProgram pram) {
	degree = pram;
}

//getters
string Student::getStudentID() {
	return studentID;
}

string Student::getFirstName() {
	return firstName;
}

string Student::getLastName() {
	return lastName;
}

string Student::getEmailAddress() {
	return emailAddress;
}
int Student::getAge() {
	return age;
}
int* Student::getCourseTime() {
	return courseTime;
}
DegreeProgram Student::getDegreeProgram() {
	return degree;
}
