/* must contain these variables:
	- student ID
	- first name
	- last name
	- email address
	- age
	- array of number of days to complete each course
	- degree program
*/

/* needed functions
	- accessor/getter for each variable
	- mutator/setter for each variable
		-all access and changes must be made using the above
	- constructor using all of the input parameters provided in the table
	- print() to print specific data
*/
#include <iostream>
#include <string>
#include <iomanip>

#include "degree.h"

using namespace std;

#ifndef STUDENT_H
#define STUDENT_H

class Student {
public:
	//constructors
	Student();
	Student(string studentIDParam, string firstNameParam, string lastNameParam, string emailAddressParam, int ageParam, int* courseTimeParam, DegreeProgram degreeProgramParam);

	void print();
	const static int courseArraySize = 3;

	//setters
	void setStudentID(string pram);
	void setFirstName(string pram);
	void setLastName(string pram);
	void setEmailAddress(string pram);
	void setAge(int pram);
	void setCourseTime(int pram[]);
	void setDegreeProgram(DegreeProgram pram);

	//getters
	string getStudentID();
	string getFirstName();
	string getLastName();
	string getEmailAddress();
	int getAge();
	int* getCourseTime();
	DegreeProgram getDegreeProgram();


	//destructor
	~Student();

private:
	string studentID;
	string firstName;
	string lastName;
	string emailAddress;
	int age;
	int* courseTime;
	DegreeProgram degree;
};
#endif